#!/usr/bin/env python3
"""Early-bailout measurement — does a VALID solution let us halt EARLIER than base?

The speedup thesis (P. Lamy): on a good solution the appliance must return SOONER than base, not
later. Base generates to END_TEXT (full answer + any trailing prose + the stop walk). The bailout
halts the GPU the instant a complete, valid code block appears (CPU validation is ~free; the GPU
tokens it skips are the saving). This measures, per task: tokens-to-first-valid-block (bailout) vs
tokens-to-END_TEXT (base). Positive delta = the early bailout is genuinely earlier."""
from __future__ import annotations
import argparse, ast, re, time
import mlx.core as mx
from mlx_lm.utils import load


def _step(model, ids, cache):
    logits = model(mx.array([ids], dtype=mx.int32), cache=cache)
    return int(mx.argmax(logits[0, -1, :]).item())


def _valid_block(text):
    m = re.search(r"```python\n(.*?)```", text, re.S)
    if not m:
        return False
    code = m.group(1)
    if "def " not in code:
        return False
    try:
        ast.parse(code)
        return True
    except SyntaxError:
        return False


def gen_measure(model, tok, prompt, end_text, eos, max_answer=1200, reasoning=False):
    ids = tok.apply_chat_template([{"role": "user", "content": prompt}],
                                  add_generation_prompt=True, reasoning=reasoning)
    cache = model.make_cache()
    nxt = _step(model, list(ids), cache)
    out, bailout_at = [], None
    last_check = 0
    t0 = time.time()
    for _ in range(max_answer):
        if nxt == end_text or (eos is not None and nxt == eos):
            break
        out.append(nxt)
        # check for a complete valid block every few tokens once we've seen a closing fence
        if bailout_at is None and len(out) - last_check >= 6:
            last_check = len(out)
            if _valid_block(tok.decode(out)):
                bailout_at = len(out)
        nxt = _step(model, [nxt], cache)
    total = len(out)
    dt = time.time() - t0
    return total, (bailout_at if bailout_at is not None else total), dt


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="/Users/pierrelamy/.lmstudio/models/north-mini-code-1.0-fs5-unified-v2")
    args = ap.parse_args()
    model, tok = load(args.model); model.eval()
    end_text = tok.encode("<|END_TEXT|>", add_special_tokens=False)[0]
    eos = getattr(tok, "eos_token_id", None)

    # a spread of tasks North handles well (good solutions) — measure the trailing tokens base emits
    TASKS = [
        ("two_sum", "Write a Python function `two_sum(nums: list[int], target: int) -> list[int]` that returns the indices of the two numbers that add up to target. Return ONLY the function in a ```python code block."),
        ("is_palindrome", "Write a Python function `is_palindrome(s: str) -> bool` that returns whether s reads the same forwards and backwards, ignoring case and non-alphanumeric characters. Return ONLY the function in a ```python code block."),
        ("fib", "Write a Python function `fib(n: int) -> int` that returns the n-th Fibonacci number (fib(0)=0, fib(1)=1). Return ONLY the function in a ```python code block."),
        ("gcd", "Write a Python function `gcd(a: int, b: int) -> int` that returns the greatest common divisor of a and b. Return ONLY the function in a ```python code block."),
        ("binary_search", "Write a Python function `binary_search(xs: list[int], target: int) -> int` that returns the index of target in sorted xs, or -1. Return ONLY the function in a ```python code block."),
        ("merge_sorted", "Write a Python function `merge_sorted(a: list[int], b: list[int]) -> list[int]` that merges two sorted lists into one sorted list. Return ONLY the function in a ```python code block."),
    ]
    print(f"{'task':16s} {'base(reason)':>13s} {'bailout(off)':>13s} {'saved':>7s} {'saved%':>7s}  {'base_s':>7s} {'bail_s':>7s}")
    tb = tbail = tbs = tbas = 0.0
    for name, prompt in TASKS:
        base_tok, _, base_s = gen_measure(model, tok, prompt, end_text, eos, reasoning=True)   # base = reasons
        bail_tok, _, bail_s = gen_measure(model, tok, prompt, end_text, eos, reasoning=False)  # bailout = no reasoning
        saved = base_tok - bail_tok
        pct = 100 * saved / base_tok if base_tok else 0
        tb += base_tok; tbail += bail_tok; tbs += base_s; tbas += bail_s
        print(f"{name:16s} {base_tok:13d} {bail_tok:13d} {saved:7d} {pct:6.1f}%  {base_s:6.1f}s {bail_s:6.1f}s")
    print(f"\nTOTAL base(reasoning)={int(tb)} tok / {tbs:.1f}s   bailout(reasoning-off,validated)={int(tbail)} tok / {tbas:.1f}s")
    print(f"→ early bailout saves {100*(tb-tbail)/tb:.0f}% of tokens and {tbs/tbas:.1f}x wallclock on GOOD solutions vs base reasoning.")
    print("  (the bailout is sound ONLY because the validator confirms the no-reasoning answer; else it escalates to reasoning.)")
