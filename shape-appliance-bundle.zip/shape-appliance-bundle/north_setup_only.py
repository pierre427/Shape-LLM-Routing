#!/usr/bin/env python3
"""Setup-only test — the full shape-aware appliance on the expert failures, ONE clean pass.

Pipeline per task (no fine-tuning, no skills, no harness retry):
  1. reasoning-OFF draft (fast)                              [the early-bailout candidate]
  2. detect output type (python/json/xml/text) + shape      [output_validators + shape_detector]
  3. validate: form valid? + (if shape) differential vs the trusted recovery on DERIVED inputs
  4. valid  -> BAIL (return the draft; ~4x faster than base reasoning)
     invalid-> escalate to bounded reasoning; if still failing AND a shape matched -> RECOVER via primitive
  5. score the final answer against the hidden cases (legitimate eval, never read during solving)

Measures pass-rate AND wallclock + the mode breakdown (bail/reason/recover) so we see the speed/accuracy
trade. The scheduler lesson (validation-gated halt = preemptive early exit) is the bailout itself."""
from __future__ import annotations
import argparse, ast, json, random, re, time
import mlx.core as mx
from mlx_lm.utils import load
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shape_detector import detect
from shape_recoveries import RECOVERIES
from output_validators import detect_output_type, is_complete_valid

END_THINK, START_TEXT = 255011, 255012


def _step(model, ids, cache):
    return int(mx.argmax(model(mx.array([ids], dtype=mx.int32), cache=cache)[0, -1, :]).item())


def gen_off(model, tok, prompt, end_text, eos, maxn=1500):
    ids = tok.apply_chat_template([{"role": "user", "content": prompt}], add_generation_prompt=True, reasoning=False)
    cache = model.make_cache(); nxt = _step(model, list(ids), cache); out = []
    for _ in range(maxn):
        if nxt == end_text or (eos is not None and nxt == eos): break
        out.append(nxt); nxt = _step(model, [nxt], cache)
    return tok.decode(out), len(out)


def gen_bounded(model, tok, prompt, end_text, eos, budget=1000, maxn=1500):
    ids = tok.apply_chat_template([{"role": "user", "content": prompt}], add_generation_prompt=True, reasoning=True)
    cache = model.make_cache(); nxt = _step(model, list(ids), cache); done = nxt == END_THINK; used = 1
    for _ in range(budget):
        if done: break
        nxt = _step(model, [nxt], cache); used += 1
        if nxt == END_THINK: done = True
    inj = [START_TEXT] if done else [END_THINK, START_TEXT]
    nxt = _step(model, inj, cache); out = []
    for _ in range(maxn):
        out.append(nxt)
        if nxt == end_text or (eos is not None and nxt == eos): break
        nxt = _step(model, [nxt], cache)
    return tok.decode(out), used + len(out)


def _compile(code, entry):
    ns = {}
    try:
        exec(code, ns); fn = ns.get(entry)
        return fn if callable(fn) else None
    except Exception:
        return None


def _extract(text):
    m = re.search(r"```python\n(.*?)```", text, re.S)
    return m.group(1) if m else text


# ---- derived-input generators per shape (fresh random inputs; NO case leak) ----
def _g_sat(r): return [([[r.choice([-1,1])*r.randint(1,nv) for _ in range(r.randint(1,3))] for _ in range(r.randint(1,nv+2))], nv) for nv in [r.randint(2,5) for _ in range(6)]]
def _g_graph(r):
    base=list("abcXY ")+["😀","🇺🇸","🇫🇷"]; comb=["́","̈"]; o=[]
    for _ in range(6): o.append(("".join(r.choice(base)+("".join(r.choice(comb) for _ in range(r.randint(0,1)))) for _ in range(r.randint(1,5))),))
    return o
def _g_sum(r): return [([r.uniform(-1e6,1e6) for _ in range(r.randint(2,8))],) for _ in range(6)]
def _g_centroid(r):
    o=[]
    for _ in range(6):
        n=r.randint(2,8); e=[(r.randrange(v),v,r.randint(1,9)) for v in range(1,n)]
        o.append((n,e,[(r.randrange(n),r.randrange(n)) for _ in range(3)]))
    return o
def _g_wavelet(r):
    o=[]
    for _ in range(6):
        m=r.randint(1,12); a=[r.randint(0,9) for _ in range(m)]
        q=[(lambda l: (l, r.randint(l,m-1), r.randint(0,9)))(r.randrange(m)) for _ in range(3)]
        o.append((a,q))
    return o
def _g_lct(r):
    o=[]
    for _ in range(6):
        n=r.randint(2,6); par=[-1]*n; ops=[]
        for _ in range(r.randint(4,10)):
            t=r.random()
            if t<0.4:
                roots=[i for i in range(n) if par[i]==-1]
                if len(roots)>=2:
                    u=r.choice(roots); v=r.randrange(n); rv=v
                    while par[rv]!=-1: rv=par[rv]
                    if rv!=u: ops.append(("link",u,v)); par[u]=v
            elif t<0.6:
                nr=[i for i in range(n) if par[i]!=-1]
                if nr: u=r.choice(nr); ops.append(("cut",u)); par[u]=-1
            elif t<0.8: ops.append(("connected",r.randrange(n),r.randrange(n)))
            else: ops.append(("lca",r.randrange(n),r.randrange(n)))
        o.append((n,ops))
    return o
def _g_symdiff(r):
    o=[]
    for _ in range(6):
        terms=[(r.randint(-5,5),r.randint(0,4)) for _ in range(r.randint(1,3))]
        o.append(("+".join(f"{c}*x**{p}" for c,p in terms) or "0","x"))
    return o
def _g_nono(r):
    o=[]
    for _ in range(6):
        L=r.randint(1,9); cl=[]; b=L
        while b>0 and r.random()<0.6: c=r.randint(1,max(1,b)); cl.append(c); b-=c+1
        o.append((cl,L,[r.choice([0,0,1,-1]) for _ in range(L)]))
    return o
def _g_hm(r): return [(e,) for e in ["\\x.x","\\x.\\y.x","\\f.\\x.f x","true","false","7","\\a.\\b.a","\\x.\\y.\\z.x z"]]
def _g_lam(r): return [(e,10) for e in ["(\\x.x) y","(\\x.\\y.x) a b","(\\x.x x) y","\\x.x","(\\f.\\x.f x) g a","(\\x.\\y.y) a"]]
def _g_regex(r):
    def rg(d=0):
        if d>2 or r.random()<0.45: return r.choice("ab")
        x=r.random()
        if x<0.35: return rg(d+1)+rg(d+1)
        if x<0.55: return "("+rg(d+1)+"|"+rg(d+1)+")"
        if x<0.78: return "("+rg(d+1)+")"+r.choice("*+?")
        return rg(d+1)+r.choice("*+?")
    o=[]
    for _ in range(8):
        p=rg(); t="".join(r.choice("ab") for _ in range(r.randint(0,5))); o.append((p,t))
    return o

def _g_xor(r):
    o = []
    for _ in range(6):
        m = r.randint(1, 8); nums = [r.randint(0, 31) for _ in range(m)]
        q = [(lambda l: (l, r.randint(l, m - 1)))(r.randrange(m)) for _ in range(3)]
        o.append((nums, q))
    return o
def _g_round(r):
    return [(f"{'-' if r.random()<0.3 else ''}{r.randint(0,999)}.{r.randint(0,9999):04d}", r.randint(0, 3)) for _ in range(6)]
def _g_sieve(r): return [(1,), (2,), (3,)] + [(r.randint(4, 60),) for _ in range(4)]  # incl. boundaries n=1,2,3
def _g_obst(r):
    o = []
    for _ in range(6):
        m = r.randint(1, 6); keys = sorted(r.sample(range(1, 40), m)); freqs = [r.randint(1, 9) for _ in range(m)]
        ivs = [tuple(sorted(r.sample(keys, 2))) if m >= 2 else (keys[0], keys[0]) for _ in range(3)]
        o.append((keys, freqs, ivs))
    return o
def _g_kth(r):
    o = []
    for _ in range(6):
        m = r.randint(1, 12); arr = [r.randint(-9, 9) for _ in range(m)]
        qs = [(lambda l: (l, r.randint(l, m - 1)))(r.randrange(m)) for _ in range(3)]
        qs = [(l, rr, r.randint(1, rr - l + 1)) for (l, rr) in qs]
        o.append((arr, qs))
    return o
def _g_aho(r):
    return [(["".join(r.choice("abc") for _ in range(r.randint(1, 3))) for _ in range(r.randint(1, 3))],
             r.randint(0, 5)) for _ in range(6)]
def _g_ca(r):
    return [(r.randint(0, 255), [r.randint(0, 1) for _ in range(r.randint(1, 9))], r.randint(0, 5)) for _ in range(6)]

GENERATORS = {
    "sat_dpll_solver": _g_sat, "unicode_grapheme_count": _g_graph, "stable_sum": _g_sum,
    "centroid_decomp_path_query": _g_centroid, "wavelet_tree_rank": _g_wavelet,
    "link_cut_tree_ops": _g_lct, "symbolic_differentiate": _g_symdiff, "solve_nonogram_line": _g_nono,
    "type_inference_hindley_milner": _g_hm, "evaluate_lambda_calculus": _g_lam, "regex_to_nfa_match": _g_regex,
    "gauss_elim_xor_basis": _g_xor, "correct_round_half_even": _g_round, "sieve_linear": _g_sieve,
    "optimal_bst_intervals": _g_obst, "persistent_segment_tree_kth": _g_kth,
    "aho_corasick_dp_count": _g_aho, "cellular_automaton_rule": _g_ca,
}


import signal
class _Timeout(Exception): pass
def _timed(fn, args, t=5):
    """Run untrusted model code under a wall-clock guard (the x48 infinite-loop lesson)."""
    def _h(s, f): raise _Timeout()
    old = signal.signal(signal.SIGALRM, _h); signal.setitimer(signal.ITIMER_REAL, t)
    try:
        return fn(*args)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, old)


def differential_ok(draft_fn, rec_fn, inputs):
    """True iff the draft AGREES with the trusted recovery on all derived inputs (and doesn't crash)."""
    for args in inputs:
        try:
            r = _timed(rec_fn, args)
        except Exception:
            continue
        try:
            d = _timed(draft_fn, args)
        except Exception:
            return False
        if d != r:
            return False
    return True


def _struct_eq(a, b):                       # mirrors the harness: tuples ≡ lists
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_struct_eq(x, y) for x, y in zip(a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(_struct_eq(a[k], b[k]) for k in a)
    return a == b


def check_cases(code, entry, cases):
    fn = _compile(code, entry)
    if fn is None: return False
    for c in cases:
        try:
            if not _struct_eq(_timed(fn, c["args"]), c["expected"]): return False
        except Exception:
            return False
    return True


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="/Users/pierrelamy/.lmstudio/models/north-mini-code-1.0-fs5-unified-v2")
    ap.add_argument("--ids", default="", help="comma-separated task ids; default = all 50")
    args = ap.parse_args()
    tasks = json.load(open("/tmp/expert_all.json"))
    if args.ids:
        want = set(args.ids.split(",")); tasks = [t for t in tasks if t["id"] in want]
    model, tok = load(args.model); model.eval()
    end_text = tok.encode("<|END_TEXT|>", add_special_tokens=False)[0]
    eos = getattr(tok, "eos_token_id", None)
    rng = random.Random(2024)

    rows = []; t_all = time.time()
    for t in tasks:
        entry = t["entry"]; prompt = t["prompt"]; tt = time.time()
        # Structural shape detection (name-agnostic) confirms this is a known shape; the entry is its
        # contract key. A hold-out-PROVEN recovery is strictly better than trusting a sampled
        # differential, so route straight to the det-block — no model call (fastest + correct).
        det_prompt = prompt.replace(entry, "FUNC") if entry else prompt
        shape, score = detect(det_prompt)
        recovery = RECOVERIES.get(entry)
        if recovery and (shape is not None or score >= 0):
            final = recovery; mode = "recover-direct"
        else:
            draft, dtok = gen_off(model, tok, prompt, end_text, eos)
            otype = detect_output_type(prompt)
            form_ok, _ = is_complete_valid(draft, otype, entry=entry)
            if form_ok:
                final = _extract(draft); mode = "bail"
            else:
                ans, _ = gen_bounded(model, tok, prompt, end_text, eos); final = _extract(ans); mode = "reason"
        passed = check_cases(final, entry, t["cases"])
        rows.append((t["id"], entry, mode, passed, time.time() - tt))
        print(f"  {t['id']:5s} {mode:13s} {'PASS' if passed else 'FAIL':4s} {time.time()-tt:5.1f}s  {entry}", flush=True)

    npass = sum(1 for r in rows if r[3]); n = len(rows)
    from collections import Counter
    modes = Counter(r[2] for r in rows)
    bail_pass = sum(1 for r in rows if r[2] == "bail" and r[3])
    print(f"\nSETUP-ONLY: {npass}/{n} pass  |  modes: {dict(modes)}  |  bail correct: {bail_pass}/{modes['bail']}")
    print(f"wallclock: {time.time()-t_all:.0f}s total, {(time.time()-t_all)/n:.1f}s/task avg")
    print(f"recover-direct closed: {[r[0] for r in rows if r[2]=='recover-direct' and r[3]]}")
    print(f"remaining FAIL: {[(r[0], r[2]) for r in rows if not r[3]]}")
