#!/usr/bin/env python3
"""Model-AGNOSTIC shape-routing appliance core.

The deterministic stack (shape_recoveries, shape_detector, output_validators) is independent of the
LLM. The only model-specific surface is a small ModelAdapter:

    class ModelAdapter:
        name: str
        def gen_fast(prompt) -> (answer_text, n_tokens)       # fast / low-reasoning path
        def gen_reasoning(prompt) -> (answer_text, n_tokens)  # escalation / high-reasoning path
        # both return the model's ANSWER text (the final channel / post-reasoning answer)

Given an adapter, run_appliance() executes the same recovery-first pipeline used for North, so a new
model is ported by writing one adapter — nothing in the recovery/detector/validator layer changes."""
from __future__ import annotations
import ast, re, signal, time
from collections import Counter
from shape_detector import detect
from shape_recoveries import RECOVERIES
from output_validators import detect_output_type, is_complete_valid


def _extract(text):
    m = re.search(r"```python\n(.*?)```", text, re.S)
    return m.group(1) if m else text


def _compile(code, entry):
    ns = {}
    try:
        exec(code, ns)
        fn = ns.get(entry)
        return fn if callable(fn) else None
    except Exception:
        return None


def _struct_eq(a, b):                          # mirrors the harness runner: tuples ≡ lists
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_struct_eq(x, y) for x, y in zip(a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        return set(a) == set(b) and all(_struct_eq(a[k], b[k]) for k in a)
    return a == b


class _Timeout(Exception):
    pass


def _timed(fn, args=(), kwargs=None, t=5):
    kwargs = kwargs or {}
    def _h(s, f): raise _Timeout()
    old = signal.signal(signal.SIGALRM, _h); signal.setitimer(signal.ITIMER_REAL, t)
    try:
        return fn(*args, **kwargs)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0); signal.signal(signal.SIGALRM, old)


def _coerce_int_keys(obj):                     # mirrors the harness: JSON string keys → int for dict[int,…]
    if isinstance(obj, dict):
        if obj and all(isinstance(k, str) and k.lstrip("-").isdigit() for k in obj):
            return {int(k): _coerce_int_keys(v) for k, v in obj.items()}
        return {k: _coerce_int_keys(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_coerce_int_keys(x) for x in obj]
    return obj


def check_cases(code, entry, cases):
    fn = _compile(code, entry)
    if fn is None:
        return False
    for c in cases:
        exp = _coerce_int_keys(c.get("expected"))
        try:
            if "args" in c:                                   # positional
                got = _timed(fn, _coerce_int_keys(c["args"]))
            else:                                             # keyword: input: {...}
                got = _timed(fn, (), _coerce_int_keys(c.get("input", {})))
            if not _struct_eq(got, exp):
                return False
        except Exception:
            return False
    return True


def run_appliance(adapter, tasks, log=True):
    """Recovery-first pipeline over `tasks` using `adapter` for the non-shape majority."""
    rows = []; t_all = time.time()
    for t in tasks:
        entry = t["entry"]; prompt = t["prompt"]; tt = time.time()
        det_prompt = prompt.replace(entry, "FUNC") if entry else prompt
        shape, score = detect(det_prompt)
        rec = RECOVERIES.get(entry)
        if rec and shape is not None:                 # known shape → proven det-block, no model call
            final = rec; mode = "recover-direct"
        else:
            draft, _ = adapter.gen_fast(prompt)        # fast path
            otype = detect_output_type(prompt)
            form_ok, _ = is_complete_valid(draft, otype, entry=entry)
            if form_ok:
                final = _extract(draft); mode = "bail"
            else:
                ans, _ = adapter.gen_reasoning(prompt); final = _extract(ans); mode = "reason"
        passed = check_cases(final, entry, t["cases"])
        rows.append((t["id"], entry, mode, passed, time.time() - tt))
        if log:
            print(f"  {t['id']:5s} {mode:13s} {'PASS' if passed else 'FAIL':4s} {time.time()-tt:5.1f}s  {entry}", flush=True)
    npass = sum(1 for r in rows if r[3]); n = len(rows); modes = Counter(r[2] for r in rows)
    if log:
        print(f"\n[{adapter.name}] SETUP-ONLY: {npass}/{n} pass  |  modes: {dict(modes)}")
        print(f"wallclock: {time.time()-t_all:.0f}s, {(time.time()-t_all)/max(1,n):.1f}s/task")
        print(f"recover-direct closed: {[r[0] for r in rows if r[2]=='recover-direct' and r[3]]}")
        print(f"remaining FAIL: {[(r[0], r[2]) for r in rows if not r[3]]}")
    return rows
