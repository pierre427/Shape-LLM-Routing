#!/usr/bin/env python3
"""Advanced deterministic instruction set — the primitives that close expert-50's CAPABILITY GAPS.

expert-50's 20 base failures are not misroutes; they are advanced algorithms/data structures, each
with a STANDARD, well-known implementation. So the advanced tier of the LLM-as-JIT's instruction set
is modeled on the canonical libraries: Python stdlib (the 'traps' collapse to it), competitive-
programming templates (KACTL / AtCoder Library / CLRS), SciPy/SymPy (numerics/symbolic), and PLT
interpreters. The model composes the specific task around a TRUSTED primitive instead of reinventing
it (the l80 lesson: 0 → 11/12 once the hard part is a primitive).

Map of base-failed expert-50 tasks → primitive (T3 = stdlib-exact, T4 = algo/DS template, T5 = PLT):
  x11 stable_sum→math.fsum  x13 round_half_even→round/decimal  x14 modpow→pow  x15 bsearch→bisect (T3)
  x02 convex_hull_tsp_dp→convex_hull+held_karp  x06 gauss_elim_xor_basis→gf2_xor_basis
  x28 karatsuba→karatsuba  x07 centroid→lca/fenwick  x48 dinic→dinic  x50 tarjan→scc_tarjan (T4)
  x33 symbolic_differentiate→parse_expr+diff  x36 regex_to_nfa→thompson  x38 sat→dpll (T5)
"""
from __future__ import annotations
import math, bisect, functools
from collections import OrderedDict, defaultdict

# ===================================================== T3 — stdlib-exact (the 'trap' killers)
def modpow(a: int, e: int, m: int) -> int:        # x14 — pow IS exact; don't reimplement
    return pow(a, e, m)
def stable_sum(xs) -> float:                       # x11 — Kahan-exact via math.fsum
    return math.fsum(xs)
def round_half_even(x: float, ndigits: int = 0):   # x13 — banker's rounding (Python's round)
    return round(x, ndigits)
def lower_bound(sorted_xs, x) -> int:              # x15 — bisect, no off-by-one
    return bisect.bisect_left(sorted_xs, x)
def upper_bound(sorted_xs, x) -> int:
    return bisect.bisect_right(sorted_xs, x)
def next_permutation(a: list) -> bool:             # x16 — in-place next lexicographic perm
    i = len(a) - 2
    while i >= 0 and a[i] >= a[i + 1]:
        i -= 1
    if i < 0:
        a.reverse(); return False
    j = len(a) - 1
    while a[j] <= a[i]:
        j -= 1
    a[i], a[j] = a[j], a[i]; a[i + 1:] = reversed(a[i + 1:]); return True
def lru_cache_factory(capacity: int):              # x24 — O(1) LRU via OrderedDict
    store = OrderedDict()
    def get(k):
        if k not in store: return None
        store.move_to_end(k); return store[k]
    def put(k, v):
        store[k] = v; store.move_to_end(k)
        if len(store) > capacity: store.popitem(last=False)
    return get, put

# ===================================================== T4 — algorithm/DS templates (KACTL/ACL/CLRS)
class DSU:                                         # union-find
    def __init__(self, n): self.p = list(range(n)); self.r = [0]*n
    def find(self, x):
        while self.p[x] != x: self.p[x] = self.p[self.p[x]]; x = self.p[x]
        return x
    def union(self, a, b):
        a, b = self.find(a), self.find(b)
        if a == b: return False
        if self.r[a] < self.r[b]: a, b = b, a
        self.p[b] = a; self.r[a] += self.r[a] == self.r[b]; return True

class Fenwick:                                     # BIT — point update, prefix sum
    def __init__(self, n): self.n = n; self.t = [0]*(n+1)
    def add(self, i, v):
        i += 1
        while i <= self.n: self.t[i] += v; i += i & -i
    def sum(self, i):                              # prefix [0, i)
        s = 0
        while i > 0: s += self.t[i]; i -= i & -i
        return s

class SparseTableRMQ:                              # x30 — O(1) range-min after O(n log n) build
    def __init__(self, a):
        n = len(a); K = max(1, n.bit_length()); self.a = a
        self.t = [a[:]] + [[0]*n for _ in range(K)]
        j = 1
        while (1 << j) <= n:
            for i in range(n - (1 << j) + 1):
                self.t[j][i] = min(self.t[j-1][i], self.t[j-1][i + (1 << (j-1))])
            j += 1
    def query(self, l, r):                         # min over [l, r]
        j = (r - l + 1).bit_length() - 1
        return min(self.t[j][l], self.t[j][r - (1 << j) + 1])

def sieve_primes(n: int) -> list:                  # x23
    s = bytearray([1]) * (n + 1); s[0:2] = b"\x00\x00"
    for i in range(2, int(n**0.5) + 1):
        if s[i]: s[i*i::i] = b"\x00" * len(s[i*i::i])
    return [i for i in range(2, n + 1) if s[i]]

def z_function(s: str) -> list:                    # x47
    n = len(s); z = [0]*n; l = r = 0
    for i in range(1, n):
        if i < r: z[i] = min(r - i, z[i - l])
        while i + z[i] < n and s[z[i]] == s[i + z[i]]: z[i] += 1
        if i + z[i] > r: l, r = i, i + z[i]
    return z

def kmp_failure(p: str) -> list:                   # prefix function
    f = [0]*len(p); k = 0
    for i in range(1, len(p)):
        while k and p[k] != p[i]: k = f[k-1]
        k += p[k] == p[i]; f[i] = k
    return f

def convex_hull(pts: list) -> list:                # x02 — Andrew's monotone chain
    pts = sorted(set(map(tuple, pts)))
    if len(pts) <= 1: return pts
    cross = lambda o, a, b: (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lo = []
    for p in pts:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    up = []
    for p in reversed(pts):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return lo[:-1] + up[:-1]

def count_inversions(a: list) -> int:              # x26 — merge-sort inversions
    def srt(x):
        if len(x) <= 1: return x, 0
        m = len(x)//2; L, cl = srt(x[:m]); R, cr = srt(x[m:])
        merged = []; i = j = inv = 0
        while i < len(L) and j < len(R):
            if L[i] <= R[j]: merged.append(L[i]); i += 1
            else: merged.append(R[j]); j += 1; inv += len(L) - i
        return merged + L[i:] + R[j:], cl + cr + inv
    return srt(a)[1]

def lis_length(a: list) -> int:                    # x21 — n log n
    tails = []
    for x in a:
        i = bisect.bisect_left(tails, x)
        if i == len(tails): tails.append(x)
        else: tails[i] = x
    return len(tails)

def karatsuba(x: int, y: int) -> int:              # x28
    if x < 16 or y < 16: return x * y
    n = max(x.bit_length(), y.bit_length()) // 2
    xh, xl = x >> n, x & ((1 << n) - 1); yh, yl = y >> n, y & ((1 << n) - 1)
    a = karatsuba(xh, yh); b = karatsuba(xl, yl); c = karatsuba(xh + xl, yh + yl)
    return (a << (2*n)) + ((c - a - b) << n) + b

def gf2_xor_basis(nums: list) -> list:             # x06 — linear basis over GF(2)
    basis = []
    for v in nums:
        for b in basis: v = min(v, v ^ b)
        if v: basis.append(v); basis.sort(reverse=True)
    return basis

def scc_tarjan(n: int, adj: dict) -> list:         # x50 — strongly connected components
    idx = [0]; ids = [-1]*n; low = [0]*n; on = [False]*n; st = []; comps = []
    import sys; sys.setrecursionlimit(1 << 20)
    def dfs(u):
        ids[u] = low[u] = idx[0]; idx[0] += 1; st.append(u); on[u] = True
        for v in adj.get(u, []):
            if ids[v] == -1: dfs(v); low[u] = min(low[u], low[v])
            elif on[v]: low[u] = min(low[u], ids[v])
        if low[u] == ids[u]:
            comp = []
            while True:
                w = st.pop(); on[w] = False; comp.append(w)
                if w == u: break
            comps.append(sorted(comp))
    for u in range(n):
        if ids[u] == -1: dfs(u)
    return comps

class Dinic:                                       # x48 — max flow
    def __init__(self, n): self.n = n; self.g = [[] for _ in range(n)]
    def add(self, u, v, c):
        self.g[u].append([v, c, len(self.g[v])]); self.g[v].append([u, 0, len(self.g[u])-1])
    def bfs(self, s, t):
        self.lvl = [-1]*self.n; self.lvl[s] = 0; q = [s]
        for u in q:
            for v, c, _ in self.g[u]:
                if c > 0 and self.lvl[v] < 0: self.lvl[v] = self.lvl[u]+1; q.append(v)
        return self.lvl[t] >= 0
    def dfs(self, u, t, f):
        if u == t: return f
        while self.it[u] < len(self.g[u]):
            e = self.g[u][self.it[u]]; v, c, r = e
            if c > 0 and self.lvl[v] == self.lvl[u]+1:
                d = self.dfs(v, t, min(f, c))
                if d > 0: e[1] -= d; self.g[v][r][1] += d; return d
            self.it[u] += 1
        return 0
    def max_flow(self, s, t):
        flow = 0
        while self.bfs(s, t):
            self.it = [0]*self.n
            while True:
                f = self.dfs(s, t, float("inf"))
                if f == 0: break
                flow += f
        return flow

def held_karp_tsp(dist: list) -> int:              # x02 — TSP DP, O(2^n n^2)
    n = len(dist); INF = float("inf"); dp = [[INF]*n for _ in range(1 << n)]; dp[1][0] = 0
    for mask in range(1 << n):
        for u in range(n):
            if dp[mask][u] == INF or not (mask >> u) & 1: continue
            for v in range(n):
                if (mask >> v) & 1: continue
                nm = mask | (1 << v)
                dp[nm][v] = min(dp[nm][v], dp[mask][u] + dist[u][v])
    return min(dp[(1 << n)-1][u] + dist[u][0] for u in range(n))


MANUAL_ADVANCED = """Advanced trusted PRIMITIVES (USE these; do NOT reimplement — they are exact):
  # T3 stdlib-exact: modpow(a,e,m), stable_sum(xs), round_half_even(x,nd), lower_bound/upper_bound,
  #   next_permutation(a), lru_cache_factory(cap)
  # T4 DS: DSU(n).find/union, Fenwick(n).add/sum, SparseTableRMQ(a).query(l,r)
  # T4 algos: sieve_primes(n), z_function(s), kmp_failure(p), convex_hull(pts), count_inversions(a),
  #   lis_length(a), karatsuba(x,y), gf2_xor_basis(nums), scc_tarjan(n,adj), Dinic(n).add/max_flow,
  #   held_karp_tsp(dist)
"""

if __name__ == "__main__":
    assert modpow(2, 10, 1000) == 24 and stable_sum([0.1]*10) == 1.0
    a = [1, 2, 3]; next_permutation(a); assert a == [1, 3, 2]
    d = DSU(5); d.union(0, 1); d.union(1, 2); assert d.find(0) == d.find(2) != d.find(3)
    f = Fenwick(5); f.add(0, 3); f.add(2, 5); assert f.sum(3) == 8
    assert SparseTableRMQ([5, 2, 4, 7, 1]).query(1, 3) == 2
    assert sieve_primes(10) == [2, 3, 5, 7]
    assert z_function("aabaab")[3] == 3 and kmp_failure("ababc")[3] == 2
    assert convex_hull([(0,0),(2,0),(1,1),(2,2),(0,2)]) and count_inversions([3,1,2]) == 2
    assert lis_length([3,1,2,4]) == 3 and karatsuba(1234, 5678) == 1234*5678
    assert gf2_xor_basis([1, 2, 3]) == [2, 1]
    assert scc_tarjan(3, {0:[1],1:[0],2:[0]}) == [[0,1],[2]] or len(scc_tarjan(3,{0:[1],1:[0],2:[0]})) == 2
    g = Dinic(4); g.add(0,1,3); g.add(0,2,2); g.add(1,3,2); g.add(2,3,3); g.add(1,2,1)
    assert g.max_flow(0, 3) == 5
    assert held_karp_tsp([[0,1,2],[1,0,1],[2,1,0]]) == 4
    print("det_primitives_advanced self-test OK —", len([n for n in dir() if not n.startswith('_')]), "symbols")
