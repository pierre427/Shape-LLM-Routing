#!/usr/bin/env python3
"""Hold-out generalization test — proves the primitives teach SHAPES, not memorized answers.

The line (P. Lamy): we must teach 'this is a SAT problem, here's how to solve any SAT', NOT 'these 5
clause-lists map to these 5 answers'. The test: run each primitive on thousands of RANDOM / NOVEL
instances it has never seen and check against an INDEPENDENT ground truth (brute force, numeric
differentiation, a reference segmenter). A memorized lookup fails held-out instances; a real
algorithm passes them all."""
from __future__ import annotations
import random, itertools, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from det_primitives_plt import dpll, symbolic_differentiate
from det_primitives_ds import unicode_grapheme_count


# ---------- dpll vs brute-force ground truth on random CNF (never the benchmark's 5) ----------
def brute_sat(clauses, nv):
    for bits in itertools.product([False, True], repeat=nv):
        a = {i + 1: bits[i] for i in range(nv)}
        if all(any((l > 0) == a[abs(l)] for l in c) for c in clauses):
            return a
    return None


def test_dpll(n=3000):
    rng = random.Random(7)
    ok = sat_agree = 0
    for _ in range(n):
        nv = rng.randint(1, 6)
        nc = rng.randint(1, nv + 4)
        clauses = [[rng.choice([-1, 1]) * rng.randint(1, nv) for _ in range(rng.randint(1, 3))] for _ in range(nc)]
        res = dpll(clauses, nv)
        truth = brute_sat(clauses, nv)
        # (a) SAT/UNSAT verdict must match ground truth; (b) if SAT, the assignment must satisfy
        verdict_ok = (res is None) == (truth is None)
        sat_ok = res is None or all(any((l > 0) == res[abs(l)] for l in c) for c in clauses)
        ok += verdict_ok and sat_ok
        sat_agree += verdict_ok
    return ok, n, sat_agree


# ---------- symbolic_differentiate vs NUMERIC ground truth on random polynomials (never seen) ----------
def test_symdiff(n=2000):
    rng = random.Random(11)
    ok = 0
    for _ in range(n):
        # random polynomial in x: sum of c*x**p
        terms = [(rng.randint(-5, 5), rng.randint(0, 4)) for _ in range(rng.randint(1, 4))]
        expr = "+".join(f"{c}*x**{p}" for c, p in terms) or "0"
        d_str = symbolic_differentiate(expr, "x")
        # numeric check: finite-difference of expr ≈ eval(derivative) at random points
        good = True
        for _ in range(5):
            x = rng.uniform(-2, 2)
            h = 1e-6
            fpp = (eval(expr, {"x": x + h}) - eval(expr, {"x": x - h})) / (2 * h)
            try:
                dval = eval(d_str, {"x": x})
            except Exception:
                good = False; break
            if abs(fpp - dval) > 1e-3 * (1 + abs(fpp)):
                good = False; break
        ok += good
    return ok, n


# ---------- grapheme vs reference segmenter on random NOVEL strings ----------
def ref_grapheme_count(s):
    """Independent reference: the `regex` module's \\X if available, else a constructed ground truth."""
    try:
        import regex
        return len(regex.findall(r"\X", s))
    except ImportError:
        return None


def test_grapheme(n=2000):
    try:
        import regex  # noqa
    except ImportError:
        return None, n, "regex module not installed — skipping (would compare vs \\X)"
    rng = random.Random(13)
    bases = list("abcXYZ ") + ["😀", "🤔", "🐍"]
    combining = ["́", "̈", "̧"]          # acute, diaeresis, cedilla
    ri = ["\U0001F1FA", "\U0001F1F8", "\U0001F1EB", "\U0001F1F7"]
    zwj = "‍"
    ok = 0
    for _ in range(n):
        parts = []
        for _ in range(rng.randint(1, 8)):
            r = rng.random()
            if r < 0.5:
                parts.append(rng.choice(bases) + "".join(rng.choice(combining) for _ in range(rng.randint(0, 2))))
            elif r < 0.7:
                parts.append(rng.choice(ri) + rng.choice(ri))            # flag pair
            else:
                parts.append("👨" + zwj + "👩")                          # zwj seq
        s = "".join(parts)
        ok += unicode_grapheme_count(s) == ref_grapheme_count(s)
    return ok, n, "vs regex \\X"


if __name__ == "__main__":
    print("HOLD-OUT GENERALIZATION — primitives on instances they have NEVER seen:\n")
    ok, n, agree = test_dpll()
    print(f"  dpll          {ok}/{n} fully correct vs brute-force ground truth "
          f"({100*ok/n:.1f}%); SAT/UNSAT verdict {agree}/{n}")
    ok, n = test_symdiff()
    print(f"  symbolic_diff {ok}/{n} match NUMERIC derivative on random polynomials ({100*ok/n:.1f}%)")
    g = test_grapheme()
    if g[0] is None:
        print(f"  grapheme      skipped — {g[2]}")
    else:
        ok, n, note = g
        print(f"  grapheme      {ok}/{n} match reference segmenter {note} ({100*ok/n:.1f}%)")
    print("\n→ 100% on unseen instances = the primitive is the SHAPE's algorithm, not a memorized table.")
