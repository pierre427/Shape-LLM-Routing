#!/usr/bin/env python3
"""Probe gpt-oss-20b harmony output: confirm channel markers + reasoning_effort + final-channel extraction."""
import time, re, glob
import mlx.core as mx
from mlx_lm.utils import load
from mlx_lm.models.cache import make_prompt_cache

MODEL = sorted(glob.glob("/Users/pierrelamy/.cache/huggingface/hub/models--openai--gpt-oss-20b/snapshots/*/"))[0]
print(f"[load] {MODEL}", flush=True)
model, tok = load(MODEL)
print(f"eos_token_id={tok.eos_token_id}", flush=True)

msgs = [{"role": "user", "content": "Write a Python function `two_sum(nums, target)` that returns the "
         "indices of the two numbers that add up to target. Return ONLY the function in a ```python code block."}]


def gen(effort, maxn=500):
    ids = tok.apply_chat_template(msgs, add_generation_prompt=True, reasoning_effort=effort)
    cache = make_prompt_cache(model)
    def step(x): return int(mx.argmax(model(mx.array([x], dtype=mx.int32), cache=cache)[0, -1, :]).item())
    nxt = step(list(ids)); out = []
    for _ in range(maxn):
        if nxt == tok.eos_token_id: break
        out.append(nxt); nxt = step([nxt])
    return out


for effort in ["low", "high"]:
    t0 = time.time(); out = gen(effort); dt = time.time() - t0
    raw = tok._tokenizer.decode(out, skip_special_tokens=False)
    print(f"\n===== effort={effort}  ({len(out)} tok, {dt:.1f}s) =====")
    print(repr(raw[:1400]))
    m = re.search(r"final<\|message\|>(.*?)(?:<\|return\|>|<\|end\|>|$)", raw, re.S)
    print("  FINAL-CHANNEL:", repr((m.group(1) if m else "(none)")[:300]))
