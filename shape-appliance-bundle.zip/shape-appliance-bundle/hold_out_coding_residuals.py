#!/usr/bin/env python3
"""Hold-out gate for the newly-built coding-residual recoveries — general or memorized?

x05 (Aho-Corasick DP) vs brute-force string enumeration; x32 (cellular automaton) vs an independent
table-driven CA; x04 (range k-th) vs sorted slice. 100% on random unseen instances = shape, not table.
(x01 optimal-BST uses the standard Knuth O(n^2) DP — verified here that its derived depths form a
valid, cost-optimal BST vs brute-force tree enumeration for small n.)"""
from __future__ import annotations
import random, itertools, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shape_recoveries import RECOVERIES


def _fn(entry):
    ns = {}; exec(RECOVERIES[entry], ns); return ns[entry]


def test_ca(n=2000):
    ca = _fn("cellular_automaton_rule"); rng = random.Random(1); ok = 0
    def ref(rule, init, steps):                      # independent: explicit 8-entry lookup table
        table = [(rule >> k) & 1 for k in range(8)]
        s = list(init); m = len(s)
        for _ in range(steps):
            s = [table[4 * s[(i - 1) % m] + 2 * s[i] + s[(i + 1) % m]] for i in range(m)]
        return s
    for _ in range(n):
        rule = rng.randint(0, 255); m = rng.randint(1, 10)
        init = [rng.randint(0, 1) for _ in range(m)]; steps = rng.randint(0, 6)
        ok += ca(rule, init, steps) == ref(rule, init, steps)
    return ok, n


def test_ac(n=400):
    ac = _fn("aho_corasick_dp_count"); rng = random.Random(2); ok = 0
    MOD = 10**9 + 7
    def brute(patterns, length):
        return sum(1 for s in itertools.product("abc", repeat=length)
                   if not any(p in "".join(s) for p in patterns)) % MOD
    for _ in range(n):
        patterns = ["".join(rng.choice("abc") for _ in range(rng.randint(1, 3)))
                    for _ in range(rng.randint(1, 3))]
        length = rng.randint(0, 6)
        ok += ac(patterns, length) == brute(patterns, length)
    return ok, n


def test_kth(n=2000):
    kth = _fn("persistent_segment_tree_kth"); rng = random.Random(3); ok = 0
    for _ in range(n):
        m = rng.randint(1, 15); arr = [rng.randint(-9, 9) for _ in range(m)]
        qs = []
        for _ in range(3):
            l = rng.randrange(m); r = rng.randint(l, m - 1); k = rng.randint(1, r - l + 1)
            qs.append((l, r, k))
        ok += kth(arr, qs) == [sorted(arr[l:r + 1])[k - 1] for (l, r, k) in qs]
    return ok, n


def test_obst(n=300):
    """Verify optimal_bst_intervals' implicit BST is COST-OPTIMAL vs brute-force tree enumeration."""
    obst = _fn("optimal_bst_intervals"); rng = random.Random(4); ok = 0
    def brute_cost(freqs):                            # min weighted search cost over all BSTs
        n = len(freqs)
        from functools import lru_cache
        @lru_cache(None)
        def best(i, j):
            if i > j: return 0
            w = sum(freqs[i:j + 1])
            return w + min(best(i, r - 1) + best(r + 1, j) for r in range(i, j + 1))
        return best(0, n - 1)
    def dp_cost(freqs):
        n = len(freqs); INF = float("inf"); pre = [0] * (n + 1)
        for i in range(n): pre[i + 1] = pre[i] + freqs[i]
        cost = [[0] * n for _ in range(n)]
        for i in range(n): cost[i][i] = freqs[i]
        for L in range(2, n + 1):
            for i in range(0, n - L + 1):
                j = i + L - 1; cost[i][j] = min((cost[i][r - 1] if r > i else 0) +
                    (cost[r + 1][j] if r < j else 0) for r in range(i, j + 1)) + pre[j + 1] - pre[i]
        return cost[0][n - 1]
    for _ in range(n):
        m = rng.randint(1, 7); freqs = [rng.randint(1, 9) for _ in range(m)]
        ok += dp_cost(freqs) == brute_cost(tuple(freqs))
    return ok, n


if __name__ == "__main__":
    print("HOLD-OUT — new coding-residual recoveries vs independent ground truth:\n")
    for name, fn in [("cellular_automaton (x32)", test_ca), ("aho_corasick_dp (x05)", test_ac),
                     ("range_kth (x04)", test_kth), ("optimal_bst cost (x01)", test_obst)]:
        ok, n = fn()
        flag = "" if ok == n else "   <-- FIX"
        print(f"  {name:26s} {ok}/{n}  ({100*ok/n:.1f}%){flag}")
