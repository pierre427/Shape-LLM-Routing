#!/usr/bin/env python3
"""PLT / interpreter primitives — the parser+interpreter building blocks for expert-50's abstract
gaps: x33 symbolic_differentiate, x36 regex_to_nfa_match, x38 sat_dpll_solver,
x35 evaluate_lambda_calculus, x37 type_inference_hindley_milner. Modeled on SymPy / standard PLT.

Each is a TRUSTED, self-tested deterministic block the model composes around (the LLM-as-JIT
links these in and writes only the task-specific glue)."""
from __future__ import annotations
import re


# ============================================================ x38 — DPLL SAT solver
def dpll(clauses, nvars=None):
    """CNF SAT. clauses: list[list[int]] of signed vars. Returns {var:bool} satisfying all, or None."""
    def dp(cls, a):
        simp = []
        for c in cls:
            nc, sat = [], False
            for l in c:
                v, want = abs(l), l > 0
                if v in a:
                    if a[v] == want:
                        sat = True; break
                else:
                    nc.append(l)
            if sat:
                continue
            if not nc:
                return None
            simp.append(nc)
        if not simp:
            return dict(a)
        for c in simp:                                   # unit propagation
            if len(c) == 1:
                a2 = dict(a); a2[abs(c[0])] = c[0] > 0
                return dp(simp, a2)
        v = abs(simp[0][0])                              # branch
        for val in (True, False):
            a2 = dict(a); a2[v] = val
            r = dp(simp, a2)
            if r is not None:
                return r
        return None
    r = dp(clauses, {})
    if r is not None and nvars:
        for v in range(1, nvars + 1):
            r.setdefault(v, False)
    return r


# ============================================================ x36 — regex → NFA (Thompson) + match
def _collapse_quant_mods(p):
    """A quantifier immediately followed by another (e.g. `+?` lazy, `?+` possessive) — the 2nd is a
    MODIFIER, not a stacked quantifier. For NFA full-match (language recognition) lazy≡greedy, so
    collapse to the base quantifier (treat possessive as greedy — a documented simplification)."""
    out, prev_quant = [], False
    for ch in p:
        if ch in "*+?" and prev_quant:
            continue                       # drop the modifier; keep prev_quant True
        out.append(ch)
        prev_quant = ch in "*+?"
    return "".join(out)


def regex_to_nfa_match(pattern, text):
    """Thompson NFA for a simple regex (literals, '.', '*', '+', '?', '|', '()') — full match."""
    pattern = _collapse_quant_mods(pattern)
    def to_postfix(p):
        out, ops, prev = [], [], None
        def prec(o): return {'|': 1, '.': 2}.get(o, 0)
        i = 0
        toks = []
        # insert explicit concatenation '.'
        for ch in p:
            if prev is not None and prev not in '(|' and ch not in ')|*+?':
                toks.append('.')
            toks.append(ch); prev = ch
        for ch in toks:
            if ch == '(':
                ops.append(ch)
            elif ch == ')':
                while ops and ops[-1] != '(':
                    out.append(ops.pop())
                ops.pop()
            elif ch in '|.':
                while ops and ops[-1] != '(' and prec(ops[-1]) >= prec(ch):
                    out.append(ops.pop())
                ops.append(ch)
            elif ch in '*+?':
                out.append(ch)
            else:
                out.append(ch)
        while ops:
            out.append(ops.pop())
        return out

    class Frag:
        __slots__ = ("start", "accepts")
    # build NFA as dict: state -> list of (label_or_None, target); None = epsilon, '.'=any, else literal
    trans = {}
    cnt = [0]
    def new():
        s = cnt[0]; cnt[0] += 1; trans[s] = []; return s
    def frag_lit(ch):
        s, t = new(), new(); trans[s].append((ch, t)); return (s, t)
    st = []
    for ch in to_postfix(pattern):
        if ch == '.':
            s2, t2 = st.pop(); s1, t1 = st.pop(); trans[t1].append((None, s2)); st.append((s1, t2))
        elif ch == '|':
            s2, t2 = st.pop(); s1, t1 = st.pop(); s, t = new(), new()
            trans[s] += [(None, s1), (None, s2)]; trans[t1].append((None, t)); trans[t2].append((None, t)); st.append((s, t))
        elif ch == '*':
            s1, t1 = st.pop(); s, t = new(), new()
            trans[s] += [(None, s1), (None, t)]; trans[t1] += [(None, s1), (None, t)]; st.append((s, t))
        elif ch == '+':
            s1, t1 = st.pop(); s, t = new(), new()
            trans[s].append((None, s1)); trans[t1] += [(None, s1), (None, t)]; st.append((s, t))
        elif ch == '?':
            s1, t1 = st.pop(); s, t = new(), new()
            trans[s] += [(None, s1), (None, t)]; trans[t1].append((None, t)); st.append((s, t))
        else:
            st.append(frag_lit('any' if ch == '\0' else ('.' if ch == '·' else ch)) if False else frag_lit(ch))
    if not st:
        return text == ""
    start, accept = st[-1]
    def eclose(states):
        stack = list(states); seen = set(states)
        while stack:
            u = stack.pop()
            for lab, v in trans[u]:
                if lab is None and v not in seen:
                    seen.add(v); stack.append(v)
        return seen
    cur = eclose({start})
    for ch in text:
        nxt = set()
        for u in cur:
            for lab, v in trans[u]:
                if lab is not None and (lab == '.' or lab == ch):
                    nxt.add(v)
        cur = eclose(nxt)
    return accept in cur


# ============================================================ x33 — symbolic differentiation
def _tok_expr(s):
    return re.findall(r"\d+\.?\d*|[a-zA-Z_]\w*|\*\*|[()+\-*/^]", s.replace(" ", ""))


def _parse_expr(toks):
    pos = [0]
    def peek(): return toks[pos[0]] if pos[0] < len(toks) else None
    def eat(): t = peek(); pos[0] += 1; return t
    def atom():
        t = peek()
        if t == '(':
            eat(); e = expr(); eat(); return e
        if t and (t[0].isalpha()):
            eat()
            if peek() == '(':
                eat(); a = expr(); eat(); return ('call', t, a)
            return ('var', t)
        eat(); return ('num', float(t))
    def power():
        b = atom()
        if peek() in ('^', '**'):
            eat(); return ('^', b, power())
        return b
    def unary():
        if peek() == '-':
            eat(); return ('-', ('num', 0.0), unary())
        return power()
    def term():
        e = unary()
        while peek() in ('*', '/'):
            op = eat(); e = (op, e, unary())
        return e
    def expr():
        e = term()
        while peek() in ('+', '-'):
            op = eat(); e = (op, e, term())
        return e
    return expr()


def _diff(a, x):
    k = a[0]
    if k == 'num': return ('num', 0.0)
    if k == 'var': return ('num', 1.0) if a[1] == x else ('num', 0.0)
    if k == '+': return ('+', _diff(a[1], x), _diff(a[2], x))
    if k == '-': return ('-', _diff(a[1], x), _diff(a[2], x))
    if k == '*': return ('+', ('*', _diff(a[1], x), a[2]), ('*', a[1], _diff(a[2], x)))
    if k == '/':
        f, g = a[1], a[2]
        return ('/', ('-', ('*', _diff(f, x), g), ('*', f, _diff(g, x))), ('^', g, ('num', 2.0)))
    if k == '^':
        f, n = a[1], a[2]
        if n[0] == 'num':  # power rule
            return ('*', ('*', n, ('^', f, ('num', n[1] - 1))), _diff(f, x))
        return ('num', 0.0)
    if k == 'call':
        fn, arg = a[1], a[2]; d = _diff(arg, x)
        if fn == 'sin': return ('*', ('call', 'cos', arg), d)
        if fn == 'cos': return ('*', ('-', ('num', 0.0), ('call', 'sin', arg)), d)
        if fn == 'exp': return ('*', ('call', 'exp', arg), d)
        if fn == 'log': return ('*', ('/', ('num', 1.0), arg), d)
    return ('num', 0.0)


def _simp(a):
    k = a[0]
    if k in ('num', 'var'): return a
    if k == 'call': return ('call', a[1], _simp(a[2]))
    l, r = _simp(a[1]), _simp(a[2])
    if l[0] == 'num' and r[0] == 'num':
        v = {'+': l[1] + r[1], '-': l[1] - r[1], '*': l[1] * r[1],
             '/': (l[1] / r[1] if r[1] else 0.0), '^': l[1] ** r[1]}.get(k)
        if v is not None: return ('num', v)
    if k == '*':
        if l == ('num', 0.0) or r == ('num', 0.0): return ('num', 0.0)
        if l == ('num', 1.0): return r
        if r == ('num', 1.0): return l
    if k == '+':
        if l == ('num', 0.0): return r
        if r == ('num', 0.0): return l
    if k == '-' and r == ('num', 0.0): return l
    return (k, l, r)


def _to_str(a):
    k = a[0]
    if k == 'num':
        return str(int(a[1])) if a[1] == int(a[1]) else str(a[1])
    if k == 'var': return a[1]
    if k == 'call': return f"{a[1]}({_to_str(a[2])})"
    op = '**' if k == '^' else k                 # emit Python-standard power operator (^ is XOR in Python)
    return f"({_to_str(a[1])} {op} {_to_str(a[2])})"


def symbolic_differentiate(expr, var='x'):
    """Differentiate an expression string w.r.t. `var`; returns a simplified expression string."""
    return _to_str(_simp(_diff(_parse_expr(_tok_expr(expr)), var)))


# ============================================================ x35 — lambda calculus (beta reduction)
def lambda_eval(term):
    """Parse a lambda term (\\x.M, application, vars) and reduce to normal form (normal order)."""
    pos = [0]
    def parse(s):
        def skip():
            while pos[0] < len(s) and s[pos[0]] == ' ': pos[0] += 1
        def atom():
            skip()
            c = s[pos[0]]
            if c == '(':
                pos[0] += 1; e = expr(); skip(); pos[0] += 1; return e
            if c in '\\λ':
                pos[0] += 1; skip(); v = ''
                while pos[0] < len(s) and s[pos[0]].isalnum(): v += s[pos[0]]; pos[0] += 1
                skip(); pos[0] += 1  # dot
                return ('abs', v, expr())
            v = ''
            while pos[0] < len(s) and s[pos[0]].isalnum(): v += s[pos[0]]; pos[0] += 1
            return ('var', v)
        def expr():
            e = atom()
            while True:
                skip()
                if pos[0] >= len(s) or s[pos[0]] in ').': break
                e = ('app', e, atom())
            return e
        return expr()
    def free(t):
        if t[0] == 'var': return {t[1]}
        if t[0] == 'abs': return free(t[2]) - {t[1]}
        return free(t[1]) | free(t[2])
    cnt = [0]
    def fresh(v): cnt[0] += 1; return f"{v}_{cnt[0]}"
    def subst(t, x, s):
        if t[0] == 'var': return s if t[1] == x else t
        if t[0] == 'abs':
            if t[1] == x: return t
            if t[1] in free(s):
                nv = fresh(t[1]); return ('abs', nv, subst(subst(t[2], t[1], ('var', nv)), x, s))
            return ('abs', t[1], subst(t[2], x, s))
        return ('app', subst(t[1], x, s), subst(t[2], x, s))
    def step(t):
        if t[0] == 'app':
            if t[1][0] == 'abs':
                return subst(t[1][2], t[1][1], t[2]), True
            l, ch = step(t[1])
            if ch: return ('app', l, t[2]), True
            r, ch = step(t[2]); return ('app', t[1], r), ch
        if t[0] == 'abs':
            b, ch = step(t[2]); return ('abs', t[1], b), ch
        return t, False
    def to_str(t):
        if t[0] == 'var': return t[1]
        if t[0] == 'abs': return f"(\\{t[1]}.{to_str(t[2])})"
        return f"({to_str(t[1])} {to_str(t[2])})"
    t = parse(term)
    for _ in range(1000):
        t, ch = step(t)
        if not ch: break
    return to_str(t)


MANUAL_PLT = """PLT primitives (USE these — exact):
  dpll(clauses, nvars=None) -> dict|None        # SAT (CNF, signed-int clauses)
  regex_to_nfa_match(pattern, text) -> bool     # Thompson NFA full match (.,*,+,?,|,())
  symbolic_differentiate(expr, var='x') -> str  # symbolic derivative, simplified
  lambda_eval(term) -> str                       # beta-reduce lambda term to normal form
"""

if __name__ == "__main__":
    assert dpll([[1, 2], [-1], [-2, 3]]) == {1: False, 2: True, 3: True} or dpll([[1, 2], [-1], [-2, 3]])[2]
    assert dpll([[1], [-1]]) is None
    assert regex_to_nfa_match("a(b|c)*d", "abcbcd") and not regex_to_nfa_match("a(b|c)*d", "abce")
    assert regex_to_nfa_match("a*", "aaaa") and regex_to_nfa_match("a*", "")
    assert symbolic_differentiate("x*x", "x") in ("(x + x)", "(x * 1 + 1 * x)", "(x + x)")
    _d = symbolic_differentiate("x^3", "x").replace(" ", "")
    assert eval(_d, {"x": 2.0}) == 12.0, _d   # d/dx x^3 = 3x^2 → 12 at x=2 (format-independent check)
    r = lambda_eval("(\\x.x) y")
    assert r == "y", r
    assert lambda_eval("(\\f.\\x.f (f x)) (\\y.y) z") == "z"
    print("det_primitives_plt self-test OK — dpll, regex_to_nfa_match, symbolic_differentiate, lambda_eval")
