# Shape Catalog — teaching SHAPES, not answers

**Thesis (P. Lamy):** the appliance must learn *"this is a SAT problem, here is how to solve any
SAT"* — never *"these 5 clause-lists map to these 5 answers."* The line between the two is
**hold-out generalization**: a primitive is only trusted as a *shape* if it solves thousands of
RANDOM/NOVEL instances against an INDEPENDENT ground truth (brute force, a different library, a
numeric check). A memorized table scores ~0% held-out; a real algorithm scores 100%.

## The methodology (3 parts per shape)

1. **Primitive** — the general algorithm that solves ANY instance of the class.
2. **Validator** — checks an attempt WITHOUT reading hidden eval cases:
   - *output verifier* (strongest): the answer is checkable on its own (a SAT assignment satisfies
     its clauses; a sort is ordered; a path is connected; a roundtrip is identity).
   - *primitive differential*: run the attempt vs the trusted primitive on derived inputs.
3. **Hold-out gate** — the acceptance test: ≥thousands of unseen instances vs independent ground
   truth, must be 100%. This is BOTH the anti-memorization guard AND a correctness fuzzer (it caught
   3 real bugs: symbolic-diff `^`→`**`, wavelet empty-subtree, regex stacked-quantifier misparse).

The serving path uses these as: generate → validate → (fail) inject mid-stream / recover via the
primitive. No harness injection; passing tasks are never modified (no regression by construction).

## Shape-proven primitives (100% hold-out vs independent ground truth)

| primitive | shape | hold-out ground truth | result |
|---|---|---|---|
| `dpll` | SAT solving | brute-force 2^n enumeration | 3000/3000 |
| `symbolic_differentiate` | polynomial calculus | numeric finite-difference | 2000/2000 |
| `unicode_grapheme_count` | UAX#29 segmentation | `regex \X` | 2000/2000 |
| `regex_to_nfa_match` | Thompson NFA | Python `re.fullmatch` | 3910/3910 |
| `WaveletTree.rank/quantile` | rank/select | naive count / sorted slice | 5000/5000 |
| `nonogram_line` | line CSP | brute-force 2^len intersection | 1500/1500 |
| `LinkCutTree` | dynamic-tree path | explicit brute-force forest (BFS) | 1222/1222 |
| `centroid_decompose` | tree decomposition | invariant (≤n/2 split, O(log n) height) | 1500/1500 |
| `lambda_eval` | β-reduction | known SKI/Church normal forms | 8/8 |

Plus the already-trusted `det_primitives` (i86/C/Python stdlib) and `det_primitives_advanced`
(DSU, Fenwick, SparseTableRMQ, sieve, z-function, KMP, convex_hull, inversions, LIS, karatsuba,
gf2_xor_basis, scc_tarjan, Dinic, held_karp) — simpler/standard, self-tested.

## Shape taxonomy across ALL harness types (from the suite survey)

**Coding (~80 shapes, nearly all verifiable):** number theory (gcd, modpow, sieve, CRT, Miller-Rabin,
totient), strings (KMP/RK/AC matching, Manacher, LCS, edit distance, RLE, Z-function, suffix
array+LCP+RMQ), DP (knapsack, coin-change, LIS, Kadane, matrix-chain, interval), sorting/selection
(binary search, quickselect, inversions, monotonic deque), graphs (BFS/Dijkstra/Bellman-Ford/
Floyd-Warshall, toposort, SCC, bipartite, bridges/articulation, max-flow, min-cost-flow, MST),
trees (LCA, centroid, heavy-light, link-cut, suffix automaton, eertree), DS (Fenwick, segment-tree
+lazy, sparse-table, persistent, Mo's, 2D-prefix, LRU), geometry (convex hull, sweep-line),
parsing (recursive-descent, shunting-yard, RPN, regex→NFA, JSON/XML, Pratt, lambda/LISP eval),
optimization (TSP/Held-Karp, Hungarian, SAT, optimal-BST), edge-case traps (Kahan sum, grapheme,
banker's rounding, modpow edges, next-perm with dups).

**Cyber (17 shapes, 13 verifiable):** STRONGEST hold-out candidates are deterministic:
JA3 TLS fingerprint (MD5 of canonical fields), hash verification (`hashlib`), base64/hex + magic
bytes, XOR key extraction (brute 0-255 + marker check), path-traversal normalization
(`Path.resolve()` + `is_relative_to`), URL hostname validation (`urlparse` + allowlist), SSRF
metadata/CIDR blocking (`ipaddress`), CSRF token validation, password-spray triage (event-count +
window), Windows event-ID classification (reference table), OCSF stream aggregation (spec-driven),
periodic-beacon detection (`gcd` of inter-arrival times), impossible-travel (great-circle + speed).
Weaker/partial (⚠️ judgment, not pure algorithm): hypothesis ranking, confidence tiers, detection-
rule synthesis, containment sequencing — these are NOT shapes (no independent ground truth).

## Historical failure set (for the setup-only clean run)

- **expert-50** (12 North residuals): x07, x11, x12, x33, x34, x35, x36, x37, x38, x39, x42, x45.
  Broader all-model fails: x01, x02, x03, x05, x06, x08, x09, x14, x17, x20, x41, x44, x49, x50.
- **ladder-100** (enhanced 100/100; consistent multi-model hard): l05, l06, l07, l09, l10, l20,
  l52, l54, l55, l57, l99 (+ model-specific l18, l19, l34, l51, l56, l78, l80, l95).
- **challenge-200** (~56 fails): algorithms (c003, c005, c010, c015, c016, c021, c037, c040–c044,
  c050), DS (c056, c057, c061, c065, c067), parsing (c083, c087, c090, c093, c094, c099, c101–c105),
  concurrency (c109–c129 cluster), numerical (c131–c148 cluster), protocol (c151 base64, c162 hex),
  geometry (c177, c180, c184, c185).
- **warmups-50**: w47 (to_snake_case).

**Acceptance rule going forward:** no primitive enters the trusted library until it passes the
hold-out gate at 100% vs an independent oracle. Shapes that have no independent ground truth
(judgment/ranking) are explicitly NOT claimed as shapes.
