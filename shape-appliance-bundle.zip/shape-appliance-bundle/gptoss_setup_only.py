#!/usr/bin/env python3
"""Setup-only shape-routing appliance for gpt-oss-20b (Cohere/North configs untouched).

Same deterministic stack + recovery-first pipeline as North; the ONLY change is the model adapter.
Run: python gptoss_setup_only.py [--ids x01,x38,...]"""
from __future__ import annotations
import argparse, json
from gptoss_adapter import GptOssAdapter
from shape_appliance import run_appliance

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", default="/tmp/expert_all.json", help="path to a dumped suite JSON")
    ap.add_argument("--ids", default="", help="comma-separated task ids subset")
    args = ap.parse_args()
    tasks = [t for t in json.load(open(args.tasks)) if t.get("entry") and t.get("cases")]
    if args.ids:
        want = set(args.ids.split(","))
        tasks = [t for t in tasks if t["id"] in want]
    run_appliance(GptOssAdapter(), tasks)
