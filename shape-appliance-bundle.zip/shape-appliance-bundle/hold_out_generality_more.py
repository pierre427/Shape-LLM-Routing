#!/usr/bin/env python3
"""Hold-out generalization for the remaining 6 primitives — each vs an INDEPENDENT ground truth.

Same discipline as hold_out_generality.py: thousands of unseen instances, checked against a DIFFERENT
implementation (Python `re`, naive counting, brute-force forests, property invariants, known lambda
facts). 100% = the primitive is the shape's algorithm, not a memorized table. Anything < 100% is a
primitive we must NOT trust as a shape until fixed."""
from __future__ import annotations
import random, re as _re, itertools, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from det_primitives_plt import regex_to_nfa_match, lambda_eval
from det_primitives_ds import WaveletTree, nonogram_line, LinkCutTree, centroid_decompose


# ---------- regex_to_nfa_match vs Python re.fullmatch (independent regex engine) ----------
def _rand_regex(rng, depth=0):
    if depth > 2 or rng.random() < 0.45:
        return rng.choice("ab")
    r = rng.random()
    if r < 0.35:
        return _rand_regex(rng, depth + 1) + _rand_regex(rng, depth + 1)
    if r < 0.55:
        return "(" + _rand_regex(rng, depth + 1) + "|" + _rand_regex(rng, depth + 1) + ")"
    if r < 0.78:
        return "(" + _rand_regex(rng, depth + 1) + ")" + rng.choice("*+?")
    return _rand_regex(rng, depth + 1) + rng.choice("*+?")


def test_regex(n=4000):
    rng = random.Random(5); ok = tested = 0
    for _ in range(n):
        pat = _rand_regex(rng)
        try:
            _re.compile("(?:%s)" % pat)
        except _re.error:
            continue
        text = "".join(rng.choice("ab") for _ in range(rng.randint(0, 6)))
        try:
            mine = regex_to_nfa_match(pat, text)
            ref = bool(_re.fullmatch(pat, text))
        except Exception:
            continue
        tested += 1; ok += (mine == ref)
    return ok, tested


# ---------- WaveletTree vs naive count / sorted-slice ----------
def test_wavelet(n=2500):
    rng = random.Random(8); ok = tested = 0
    for _ in range(n):
        m = rng.randint(1, 40); arr = [rng.randint(0, 9) for _ in range(m)]
        wt = WaveletTree(arr)
        c = rng.randint(0, 9); i = rng.randint(0, m)
        tested += 1; ok += (wt.rank(c, i) == arr[:i].count(c))
        if m >= 1:
            l = rng.randint(0, m - 1); r = rng.randint(l + 1, m); k = rng.randint(0, r - l - 1)
            tested += 1; ok += (wt.quantile(l, r, k) == sorted(arr[l:r])[k])
    return ok, tested


# ---------- nonogram_line vs brute-force over all 2^length lines (different code path) ----------
def _brute_nonogram(clues, length, known):
    valid = []
    for mask in range(1 << length):
        line = [(mask >> i) & 1 for i in range(length)]
        if any(known[k] is not None and known[k] != line[k] for k in range(length)):
            continue
        runs = [len(g) for g in "".join(map(str, line)).split("0") if g]
        if runs == list(clues):
            valid.append(line)
    if not valid:
        return None
    out = []
    for k in range(length):
        vals = {v[k] for v in valid}
        out.append(next(iter(vals)) if len(vals) == 1 else None)
    return out


def test_nonogram(n=1500):
    rng = random.Random(3); ok = tested = 0
    for _ in range(n):
        length = rng.randint(1, 11)
        # random clues that could fit
        clues = []
        budget = length
        while budget > 0 and rng.random() < 0.6:
            c = rng.randint(1, max(1, budget)); clues.append(c)
            budget -= c + 1
        known = [rng.choice([None, None, None, 0, 1]) for _ in range(length)]
        try:
            mine = nonogram_line(clues, length, known)
        except Exception:
            mine = "ERR"
        ref = _brute_nonogram(clues, length, known)
        tested += 1; ok += (mine == ref)
    return ok, tested


# ---------- LinkCutTree vs explicit brute-force forest ----------
def _bfs_conn(adj, u, v):
    seen = {u}; st = [u]
    while st:
        x = st.pop()
        if x == v:
            return True
        for y in adj[x]:
            if y not in seen:
                seen.add(y); st.append(y)
    return v in seen


def _bfs_path_sum(adj, vals, u, v):
    prev = {u: -1}; st = [u]
    while st:
        x = st.pop()
        if x == v:
            break
        for y in adj[x]:
            if y not in prev:
                prev[y] = x; st.append(y)
    s = 0; x = v
    while x != -1:
        s += vals[x]; x = prev[x]
    return s


def test_lct(n=600):
    rng = random.Random(9); ok = tested = 0
    for _ in range(n):
        m = rng.randint(2, 9); vals = [rng.randint(1, 9) for _ in range(m)]
        lct = LinkCutTree(m, vals); adj = {i: set() for i in range(m)}
        for _ in range(rng.randint(4, 16)):
            u, v = rng.randrange(m), rng.randrange(m)
            if u == v:
                continue
            op = rng.choice(["link", "cut", "conn", "path"])
            if op == "link" and not _bfs_conn(adj, u, v):
                lct.link(u, v); adj[u].add(v); adj[v].add(u)
            elif op == "cut" and v in adj[u]:
                lct.cut(u, v); adj[u].discard(v); adj[v].discard(u)
            elif op == "conn":
                tested += 1; ok += (lct.connected(u, v) == _bfs_conn(adj, u, v))
            elif op == "path" and _bfs_conn(adj, u, v):
                tested += 1; ok += (lct.path_sum(u, v) == _bfs_path_sum(adj, vals, u, v))
    return ok, tested


# ---------- centroid_decompose vs defining invariant (each removal splits ≤ half; depth ≤ log n) ----------
def test_centroid(n=1500):
    rng = random.Random(10); ok = 0
    for _ in range(n):
        m = rng.randint(1, 40)
        adj = {i: [] for i in range(m)}
        for v in range(1, m):
            u = rng.randrange(v); adj[u].append(v); adj[v].append(u)
        cpar, order = centroid_decompose(m, adj)
        good = sorted(order) == list(range(m))                 # permutation of all nodes
        depth = {}
        for c in order:
            depth[c] = 0 if cpar[c] == -1 else depth[cpar[c]] + 1
        good = good and (not depth or max(depth.values()) <= m.bit_length() + 1)   # O(log n) height
        ok += good
    return ok, n


# ---------- lambda_eval vs KNOWN combinator/Church-arithmetic normal forms (theory ground truth) ----------
def test_lambda():
    cases = [
        ("(\\x.x) a", "a"),
        ("(\\x.\\y.x) a b", "a"),
        ("(\\x.\\y.y) a b", "b"),
        ("(\\x.\\y.\\z.x z (y z)) (\\x.\\y.x) (\\x.\\y.x) a", "a"),     # S K K = I
        ("(\\f.\\x.f (f x)) g a", "g (g a)"),                          # Church 2
        ("(\\f.\\x.f (f (f x))) g a", "g (g (g a))"),                  # Church 3
        ("(\\m.\\n.\\f.\\x.m f (n f x)) (\\f.\\x.f x) (\\f.\\x.f x) g a", "g (g a)"),  # 1+1=2
        ("(\\p.\\q.p q p) (\\x.\\y.x) (\\x.\\y.y) a b", "b"),          # TRUE AND FALSE = FALSE
    ]
    ok = 0
    for term, expected in cases:
        try:
            ok += (lambda_eval(term) == lambda_eval(expected))        # same canonicalizer both sides
        except Exception:
            pass
    return ok, len(cases)


if __name__ == "__main__":
    print("HOLD-OUT GENERALIZATION — remaining 6 primitives vs INDEPENDENT ground truth:\n")
    for name, fn in [("regex_to_nfa_match", test_regex), ("WaveletTree", test_wavelet),
                     ("nonogram_line", test_nonogram), ("LinkCutTree", test_lct),
                     ("centroid_decompose", test_centroid), ("lambda_eval", test_lambda)]:
        ok, n = fn()
        pct = 100 * ok / n if n else 0
        flag = "" if ok == n else "   <-- NOT shape-proven, FIX before trusting"
        print(f"  {name:20s} {ok}/{n}  ({pct:.1f}%){flag}")
    print("\n→ 100% on unseen instances = the shape's algorithm. <100% = do not trust as a shape.")
