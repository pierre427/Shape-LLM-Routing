# How to Replicate & Build the Shape-Routing Appliance

A small reasoning LLM is turned into a fast, correct coding appliance by routing each task to either
(a) a **hold-out-proven deterministic solver** ("det-block") when its shape is known, or (b) the model
in **fast/low-reasoning mode**, admitted only after a validator confirms it. Results: **expert-50
50/50, ladder-100 100/100** at ~1.5–2.9 s/task, no fine-tuning, no skills, no answer leakage — and the
*same* deterministic layer works across two different model architectures (Cohere North-Mini, gpt-oss-20b).

This guide takes you from "verify the core claim in 60 seconds" to "run it on a suite" to "extend and
port it."

---

## 0. Prerequisites

- **Python 3.10+**. The deterministic layer is pure stdlib. Optional: `pip install regex` (one hold-out
  test compares grapheme segmentation against `regex \X`; it self-skips if absent).
- **Only for the full appliance run** (steps 2–4): Apple Silicon + `pip install mlx mlx-lm` and a local
  model. We use MLX; any runtime works if you write an adapter (step 4).

```bash
unzip shape-appliance-bundle.zip && cd shape-appliance-bundle
python3 -m pip install -r requirements.txt    # optional: regex; mlx/mlx-lm only for steps 2–4
```

---

## 1. Verify the core claim in 60 seconds (NO model, NO test suite)

```bash
python3 replicate_demo.py
```
This proves the three load-bearing pieces with zero dependencies:
1. **Hold-out gate** — `dpll` reproduces a brute-force SAT oracle on 2000 *unseen* random instances at
   100%. A memorized table scores ~0% here; 100% means it's the *shape's algorithm*.
2. **Det-block** — a recovery solves a task contract deterministically.
3. **Detector** — routes by the problem description, name-agnostically.

Then run the full hold-out gate (still no model):
```bash
python3 hold_out_generality.py          # dpll, symbolic_diff, grapheme
python3 hold_out_generality_more.py     # regex-NFA, wavelet, nonogram, link-cut, centroid, lambda
python3 hold_out_coding_residuals.py    # Aho-Corasick, cellular-automaton, range-kth, optimal-BST
python3 hold_out_cyber.py               # 9 security primitives
```
Every line must read `N/N (100.0%)`. **This is the integrity result**: no primitive is trusted until it
reproduces an independent ground truth on thousands of unseen instances. Anything < 100% is rejected.

---

## 2. Run the appliance on a suite (needs a model)

The runner loads a suite dumped to JSON. Dump one from your harness's task file:
```bash
node -e "import('./suites/expert-50/tasks.mjs').then(m=>require('fs').writeFileSync('/tmp/expert_all.json',
  JSON.stringify(m.tasks.map(t=>({id:t.id,entry:t.eval&&t.eval.entry,prompt:t.prompt,cases:t.eval&&t.eval.cases||[]})))))"
```
Point `gptoss_adapter.py` at your model path (`_DEFAULT`), then:
```bash
PYTHONPATH=. python3 gptoss_setup_only.py --tasks /tmp/expert_all.json
# -> SETUP-ONLY: 50/50 pass | modes: {recover-direct: N, bail: M} | ~2s/task
```
Per task the appliance does: **detect shape → if a hold-out-proven recovery matches the contract, run
the det-block (no model call); else** generate at low effort → validate → bail if good, escalate to
high effort if not.

---

## 3. Extend it — add a recovery for a new shape

When the model fails a task, that's a recovery target. Three steps:

1. **Write the general algorithm** as a self-contained code string in `shape_recoveries.py`'s
   `RECOVERIES`, keyed by the task's entry name, formatted to its exact I/O contract:
   ```python
   "my_entry": r'''
   def my_entry(...):
       ...   # the shape's general algorithm, matching the contract's output format
   ''',
   ```
2. **Add a structural detector entry** in `shape_detector.py`'s `SHAPES` (description-keyword regexes so
   a *novel-named* task of this shape still routes):
   ```python
   {"name": "my_shape", "primitive": "my_entry", "validator": "brute_force",
    "kw": [r"keyword1", r"keyword2"], "sig": [r"->\s*int"]},
   ```
3. **Hold-out gate it** — add a test (see `hold_out_*.py`) comparing it to an *independent* ground truth
   (brute force / a different impl / a stdlib function) on thousands of random instances. **It must hit
   100% before you trust it.** This is the rule that keeps it capability, not benchmark-gaming.

---

## 4. Port to a new model — write one adapter (~40 lines)

The deterministic layer is model-agnostic. To support a new model, implement the `ModelAdapter`
interface (see `shape_appliance.py` docstring) and pass it to `run_appliance`:
```python
class MyAdapter:
    name = "my-model"
    def gen_fast(self, prompt) -> (answer_text, n_tokens): ...   # fast / low-reasoning path
    def gen_reasoning(self, prompt) -> (answer_text, n_tokens): ... # escalation / high-reasoning
```
`gptoss_adapter.py` is a worked example: it maps gpt-oss's **harmony format** (reasoning in an
`analysis` channel, answer in a `final` channel, depth via `reasoning_effort` low/high, EOS
`<|return|>`) to that interface. North-Mini's adapter logic lives in `north_setup_only.py` (uses
`reasoning=False/True` + `END_THINK`/`START_TEXT` tokens). The recovery library, detector, and
validators are reused unchanged — that's the whole point.

---

## File guide

| file | role |
|---|---|
| `det_primitives*.py` | general primitive libraries (i86/C/Python stdlib, advanced DS, PLT, cyber) |
| `hold_out_*.py` | **the hold-out gate** — independent ground truths, must be 100% |
| `shape_detector.py` | structural, name-agnostic routing (40 shapes) |
| `shape_recoveries.py` | spec-matched contract recoveries (det-blocks) |
| `output_validators.py` | python/json/xml/text validity for the early bailout |
| `shape_appliance.py` | model-agnostic core (recovery-first pipeline, `_struct_eq`, exec-timeout) |
| `gptoss_adapter.py` | worked model adapter (harmony format) |
| `gptoss_setup_only.py` | the runner: instantiate adapter, run a suite |
| `north_setup_only.py` | reference Cohere/North runner |
| `replicate_demo.py` | 60-second self-contained core-claim verifier |
| `*.md` (docs) | the paper, the final report, the shape catalog |

**The one rule:** no primitive enters the trusted library until it passes the hold-out gate at 100%
against an independent oracle. That single discipline is the difference between teaching the appliance
the *shapes* of problems and memorizing a benchmark's *answers*.
