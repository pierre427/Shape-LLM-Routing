#!/usr/bin/env python3
"""Hold-out generalization test for the CYBER primitives — proves they teach SHAPES, not memorized
answers. For each primitive we generate thousands of RANDOM / NOVEL inputs and check against an
INDEPENDENT ground truth (a different implementation, a stdlib function, or constructed
known-answer inputs). A memorized lookup fails held-out instances; a real algorithm passes them all.

Anything < 100% means the primitive is NOT shape-proven and must be fixed."""
from __future__ import annotations
import random, sys, os, base64, hashlib, posixpath, math, ipaddress

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from det_primitives_cyber import (
    sha256_hex, decode_and_magic, xor_break_single, normalize_path,
    url_hostname_allowed, is_ssrf_target, detect_beacon, haversine_kmh, classify_win_event,
)


# ---------- sha256_hex vs hashlib directly + the canonical empty-string vector ----------
def test_sha256(n=4000):
    rng = random.Random(101)
    ok = 0
    # known-answer: empty string
    if sha256_hex("") == "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855":
        ok += 1
    total = n + 1
    for _ in range(n):
        blob = bytes(rng.randrange(256) for _ in range(rng.randint(0, 64)))
        truth = hashlib.sha256(blob).hexdigest()
        got = sha256_hex(blob)
        # determinism: same input twice -> same digest; correctness vs stdlib
        ok += (got == truth and got == sha256_hex(blob))
    return ok, total


# ---------- decode_and_magic on constructed known payloads (each magic, both encodings) ----------
def test_decode_and_magic(n=4000):
    rng = random.Random(102)
    magics = [
        (b"MZ", "pe"), (b"PK\x03\x04", "zip"), (b"\x7fELF", "elf"),
        (b"%PDF", "pdf"), (b"GIF8", "gif"), (b"\x89PNG\r\n\x1a\n", "png"),
    ]
    ok = 0
    for _ in range(n):
        r = rng.random()
        body = bytes(rng.randrange(256) for _ in range(rng.randint(0, 24)))
        if r < 0.75:
            sig, expected = rng.choice(magics)
            raw = sig + body
        else:
            # random NON-EMPTY non-magic body (an empty payload is genuinely 'invalid', not 'unknown',
            # so we never feed an empty blob into the unknown branch).
            raw = body if body else bytes([rng.randrange(256)])
            expected = None
        enc = base64.b64encode(raw).decode() if rng.random() < 0.5 else raw.hex()
        got = decode_and_magic(enc)
        if expected is None:
            # independent ground truth: does the decoded blob start with ANY known magic?
            known = [b"MZ", b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08", b"\x7fELF",
                     b"%PDF", b"GIF8", b"\x89PNG"]
            truth = next((nm for s, nm in
                          zip(known, ["pe", "zip", "zip", "zip", "elf", "pdf", "gif", "png"])
                          if raw.startswith(s)), "unknown")
            ok += (got == truth)
        else:
            ok += (got == expected)
    return ok, n


# ---------- xor_break_single: random plaintext w/ embedded crib, XOR'd by a known key ----------
def test_xor_break(n=4000):
    rng = random.Random(103)
    ok = 0
    for _ in range(n):
        key = rng.randrange(256)
        crib = bytes(rng.randrange(256) for _ in range(rng.randint(2, 6)))
        pre = bytes(rng.randrange(256) for _ in range(rng.randint(0, 10)))
        post = bytes(rng.randrange(256) for _ in range(rng.randint(0, 10)))
        plaintext = pre + crib + post
        cipher = bytes(b ^ key for b in plaintext)
        rec = xor_break_single(cipher, crib)
        # ground truth: the recovered key must actually reveal the crib (a different key may also work
        # if the crib happens to appear under it — that is still a VALID answer for this primitive).
        if rec == -1:
            ok += 0
        else:
            dec = bytes(b ^ rec for b in cipher)
            ok += (crib in dec)
    return ok, n


# ---------- normalize_path vs posixpath.normpath + independent within-base check ----------
def test_normalize_path(n=4000):
    rng = random.Random(104)
    segs = ["a", "b", "c", "..", ".", "d", "e"]
    ok = 0
    for _ in range(n):
        base = "/" + "/".join(rng.choice(["srv", "data", "app", "var"]) for _ in range(rng.randint(1, 3)))
        npath = rng.randint(0, 6)
        path = "/".join(rng.choice(segs) for _ in range(npath))
        got = normalize_path(base, path)
        # INDEPENDENT ground truth, computed differently from the primitive:
        base_norm = posixpath.normpath("/" + base.strip("/"))
        joined = posixpath.normpath(posixpath.join(base_norm, path))
        try:
            inside = (os.path.commonpath([base_norm, joined]) == base_norm)
        except ValueError:
            inside = False
        truth = joined if inside else None
        ok += (got == truth)
    return ok, n


# ---------- url_hostname_allowed vs exact set membership of the parsed host ----------
def test_url_hostname_allowed(n=4000):
    from urllib.parse import urlparse
    rng = random.Random(105)
    labels = ["app", "api", "example", "com", "net", "evil", "internal", "corp", "co"]
    ok = 0
    for _ in range(n):
        host = ".".join(rng.choice(labels) for _ in range(rng.randint(2, 4)))
        allow = [".".join(rng.choice(labels) for _ in range(rng.randint(2, 4)))
                 for _ in range(rng.randint(1, 3))]
        # adversarial: sometimes inject a suffix/substring trick relative to an allowlist entry
        r = rng.random()
        if r < 0.3 and allow:
            host = allow[0] + "." + rng.choice(["evil.com", "attacker.net"])      # suffix trick
        elif r < 0.45 and allow:
            host = rng.choice(["x", "not"]) + allow[0]                            # substring trick
        elif r < 0.6 and allow:
            host = allow[0]                                                       # legit exact match
        url = "https://" + host + "/path?q=1"
        got = url_hostname_allowed(url, allow)
        # INDEPENDENT ground truth: exact membership of the urllib-parsed host (lowercased)
        parsed = (urlparse(url).hostname or "").lower().rstrip(".")
        truth = parsed in {a.lower().rstrip(".") for a in allow}
        ok += (got == truth)
    return ok, n


# ---------- is_ssrf_target vs ipaddress.is_private/is_loopback/is_link_local + metadata IP ----------
def test_is_ssrf(n=4000):
    rng = random.Random(106)
    ok = 0
    def rand_ipv4():
        return ".".join(str(rng.randrange(256)) for _ in range(4))
    pools = [
        lambda: f"10.{rng.randrange(256)}.{rng.randrange(256)}.{rng.randrange(256)}",
        lambda: f"172.{rng.randint(16,31)}.{rng.randrange(256)}.{rng.randrange(256)}",
        lambda: f"192.168.{rng.randrange(256)}.{rng.randrange(256)}",
        lambda: f"127.{rng.randrange(256)}.{rng.randrange(256)}.{rng.randrange(256)}",
        lambda: f"169.254.{rng.randrange(256)}.{rng.randrange(256)}",
        lambda: "169.254.169.254",
        lambda: "::1",
        lambda: f"fc00::{rng.randrange(65536):x}",
        lambda: f"fd00::{rng.randrange(65536):x}",
        rand_ipv4,                     # may land anywhere (public or private)
        lambda: f"{rng.randint(1,9)}.{rng.randrange(256)}.{rng.randrange(256)}.{rng.randrange(256)}",
        lambda: "not-an-ip",
        lambda: "example.com",
    ]
    metadata = {"169.254.169.254", "fd00:ec2::254"}
    for _ in range(n):
        host = rng.choice(pools)()
        got = is_ssrf_target(host)
        # INDEPENDENT ground truth via ipaddress
        if host in metadata:
            truth = True
        else:
            try:
                ip = ipaddress.ip_address(host)
                truth = bool(ip.is_private or ip.is_loopback or ip.is_link_local)
            except ValueError:
                truth = False
        ok += (got == truth)
    return ok, n


# ---------- detect_beacon on constructed periodic vs non-periodic series ----------
def test_detect_beacon(n=4000):
    rng = random.Random(107)
    ok = 0
    for _ in range(n):
        if rng.random() < 0.6:
            # periodic: period P with jitter within +/- tol (so EVERY gap stays within tol of P)
            P = rng.randint(10, 600)
            tol = rng.randint(0, max(1, P // 10))
            t = rng.randint(0, 10000)
            ts = [t]
            for _ in range(rng.randint(3, 12)):
                gap = P + rng.randint(-tol, tol)
                gap = max(1, gap)
                t += gap
                ts.append(t)
            got = detect_beacon(ts, tol)
            # ground truth: a dominant interval near P should be recovered, within tol of P
            ok += (got != 0 and abs(got - P) <= tol)
        else:
            # non-periodic: gaps deliberately spread far beyond tol -> must return 0
            tol = rng.randint(0, 5)
            t = rng.randint(0, 10000)
            ts = [t]
            for _ in range(rng.randint(3, 12)):
                t += rng.randint(1, 1000)
                ts.append(t)
            got = detect_beacon(ts, tol)
            # INDEPENDENT ground truth: gaps cluster around a common value iff some center C exists with
            # every gap in [C-tol, C+tol], i.e. max-min <= 2*tol (computed differently from the primitive).
            gaps = [ts[i + 1] - ts[i] for i in range(len(ts) - 1)]
            clustered = (max(gaps) - min(gaps)) <= 2 * tol
            ok += ((got != 0) == clustered)
    return ok, n


# ---------- haversine_kmh vs an INDEPENDENT haversine implementation ----------
def _ref_haversine_kmh(lat1, lon1, t1, lat2, lon2, t2):
    """Independent reference using the spherical law of cosines (different formula than the primitive)."""
    if t2 == t1:
        return 0.0
    R = 6371.0088
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dlon = math.radians(lon2 - lon1)
    cosc = math.sin(p1) * math.sin(p2) + math.cos(p1) * math.cos(p2) * math.cos(dlon)
    cosc = max(-1.0, min(1.0, cosc))
    dist = R * math.acos(cosc)
    hours = abs(t2 - t1) / 3600.0
    return dist / hours


def test_haversine(n=4000):
    rng = random.Random(108)
    ok = 0
    for _ in range(n):
        lat1 = rng.uniform(-89, 89); lon1 = rng.uniform(-180, 180)
        lat2 = rng.uniform(-89, 89); lon2 = rng.uniform(-180, 180)
        t1 = rng.randint(0, 10**9)
        dt = rng.randint(1, 86400)
        t2 = t1 + dt
        got = haversine_kmh(lat1, lon1, t1, lat2, lon2, t2)
        truth = _ref_haversine_kmh(lat1, lon1, t1, lat2, lon2, t2)
        # law-of-cosines is numerically weak at tiny distances; tolerate a relative + absolute slack
        ok += (abs(got - truth) <= 1e-3 * (1 + abs(truth)) + 1e-2)
    # known-answer: t2 == t1 -> 0.0
    ok2 = ok + (haversine_kmh(10, 20, 5, 30, 40, 5) == 0.0)
    return ok2, n + 1


# ---------- classify_win_event: exhaustive over known IDs + random unknowns -> 'other' ----------
def test_classify_win_event(n=4000):
    ref = {
        4624: "logon_success", 4625: "logon_failure", 4634: "logoff", 4688: "process_create",
        4720: "account_created", 4724: "password_reset", 1102: "log_cleared",
        7045: "service_install", 4698: "scheduled_task", 10: "process_access",
    }
    rng = random.Random(109)
    ok = total = 0
    # exhaustive over the known table
    for eid, label in ref.items():
        ok += (classify_win_event(eid) == label); total += 1
    # random unknown IDs (avoid colliding with a known ID) -> 'other'
    for _ in range(n):
        eid = rng.randint(-10000, 60000)
        truth = ref.get(eid, "other")
        ok += (classify_win_event(eid) == truth); total += 1
    return ok, total


if __name__ == "__main__":
    print("HOLD-OUT GENERALIZATION — CYBER primitives on instances they have NEVER seen:\n")
    rows = [
        ("sha256_hex",          test_sha256()),
        ("decode_and_magic",    test_decode_and_magic()),
        ("xor_break_single",    test_xor_break()),
        ("normalize_path",      test_normalize_path()),
        ("url_hostname_allowed",test_url_hostname_allowed()),
        ("is_ssrf_target",      test_is_ssrf()),
        ("detect_beacon",       test_detect_beacon()),
        ("haversine_kmh",       test_haversine()),
        ("classify_win_event",  test_classify_win_event()),
    ]
    all_perfect = True
    for name, (ok, n) in rows:
        pct = 100.0 * ok / n
        all_perfect &= (ok == n)
        print(f"  {name:<22} {ok}/{n} ({pct:.1f}%)")
    print()
    if all_perfect:
        print("→ 100% on unseen instances = every primitive is the SHAPE's algorithm, not a memorized table.")
    else:
        print("→ FAIL: a primitive scored < 100% — it is NOT shape-proven and must be fixed.")
        sys.exit(1)
